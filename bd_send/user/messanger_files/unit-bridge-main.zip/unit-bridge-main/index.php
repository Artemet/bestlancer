<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="local_style/app.css">
    <link rel="stylesheet" href="layouts_style/header_line.css">
    <link rel="stylesheet" href="layouts_style/list_arrow.css">
    <link rel="stylesheet" href="banner.css">
    <link rel="stylesheet" href="./swiper-bundle.min.css" />
    <link rel="icon" href="res/web_logo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Hind&family=Roboto+Condensed:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="local_style/home.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <title>Unit Bridge</title>
</head>

<body>
    <div class="web_content">
        <?php
        include "layouts/header_line.php";
        include "layouts/list_arrow.php";
        include "baner.php";
        ?>
        <div class="step_container">
            <div class="step">
                <div class="step_name">
                    <div>
                        <p class="step_number">01.</p>
                    </div>
                    <div>
                        <p class="step_value">EXPERT STAFF</p>
                    </div>
                </div>
                <div>
                    <img src="res/Depositphotos_25045335_original-1.jpg" alt="" class="main_image">
                </div>
                <div>
                    <p class="step_information">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enetis commodo,
                        neque quam pharetra dolor,
                        nec lacinia urna quam. nisi in enenatis commodo</p>
                </div>
                <div class="more">
                    <div>
                        <p>READ MORE</p>
                    </div>
                    <div>
                        <img src="res/arrow-home.png" alt="">
                    </div>
                </div>
            </div>
            <div class="step">
                <div class="step_name">
                    <div>
                        <p class="step_number">02.</p>
                    </div>
                    <div>
                        <p class="step_value">LOGISTIC SERVICES</p>
                    </div>
                </div>
                <div>
                    <img src="res/Depositphotos_25045335_original1.jpg" alt="" class="main_image">
                </div>
                <div>
                    <p class="step_information">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enetis commodo,
                        neque quam pharetra dolor,
                        nec lacinia urna quam. nisi in enenatis commodo</p>
                </div>
                <div class="more">
                    <div>
                        <p>READ MORE</p>
                    </div>
                    <div>
                        <img src="res/arrow-home.png" alt="">
                    </div>
                </div>
            </div>
            <div class="step">
                <div class="step_name">
                    <div>
                        <p class="step_number">03.</p>
                    </div>
                    <div>
                        <p class="step_value">GROUND SHIPPING</p>
                    </div>
                </div>
                <div>
                    <img src="res/Depositphotos_25045335_original2.jpg" alt="" class="main_image">
                </div>
                <div>
                    <p class="step_information">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enetis commodo,
                        neque quam pharetra dolor,
                        nec lacinia urna quam. nisi in enenatis commodo</p>
                </div>
                <div class="more">
                    <div>
                        <p>READ MORE</p>
                    </div>
                    <div>
                        <img src="res/arrow-home.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="service_container">
            <div>
                <div>
                    <p class="block_name">SERVICES</p>
                </div>
                <div>
                    <h2>WHAT WE CAN DO FOR YOU</h2>
                </div>
            </div>
            <div class="services_wrapper">
                <div class="wrapper_part">
                    <div class="service active_service">
                        <div><img src="res/hands.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">About Our <br> Company</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                    <div class="service">
                        <div><img src="res/plane.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">AIR <br> FREIGHT</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                    <div class="service">
                        <div><img src="res/boat.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">SEA <br> FREIGHT</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                    <div class="service">
                        <div><img src="res/truck.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">GROUND <br> CARGO</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                </div>
                <div class="wrapper_part">
                    <div class="service">
                        <div><img src="res/box.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">PACKAGING <br> OPTIONS</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                    <div class="service">
                        <div><img src="res/planet.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">PROJECT <br> LOGISTICS</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                    <div class="service">
                        <div><img src="res/map.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">SUPPLY CHAIN <br> MANAGEMENT</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                    <div class="service">
                        <div><img src="res/level_arrow.png" alt="" draggable="false"></div>
                        <div class="link">
                            <a href="">WAREHOUSING <br> SERVICE</a>
                        </div>
                        <div>
                            <p class="about_service">Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enena comm
                                neque
                                quam pharetra</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="history_request_container">
            <div class="history">
                <div>
                    <p class="block_name">HISTORY</p>
                </div>
                <div>
                    <h2>OUR COMPANY PROGRESS</h2>
                </div>
                <div class="image">
                    <img src="res/Depositphotos_36835815_original-4.jpg" alt="">
                </div>
                <div class="rates">
                    <div class="rate">
                        <div class="information">
                            <p>2014</p>
                        </div>
                        <div class="rate_line">
                            <div class="main_line">
                                <div class="percent">
                                    <span id="0" class="work">0%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rate">
                        <div class="information">
                            <p>2015</p>
                        </div>
                        <div class="rate_line">
                            <div class="main_line">
                                <div class="percent">
                                    <span id="1" class="work">0%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rate">
                        <div class="information">
                            <p>2016</p>
                        </div>
                        <div class="rate_line">
                            <div class="main_line">
                                <div class="percent">
                                    <span id="2" class="work">0%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="about">
                    <p>Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enetis commodo, neque quam pharetra dolor,
                        nec lacinia urna quam. nisi in enenatis commodo Praesent eu rhoncus nibh. Quisque tincidunt,
                        nisi in enetis commodo, neque quam pharetra dolor, nec lacinia urna quam. nisi in enenatis
                        commodo Praesent eu rhoncus nibh. Quisque tincidunt, nisi in enetis commodo, neque quam pharetra
                        dolor.</p>
                </div>
            </div>
            <div>
                <div>
                    <p class="block_name">QUESTIONS</p>
                </div>
                <div>
                    <h2>REQUEST A QUICK QUOTE</h2>
                </div>
                <div class="application_box">
                    <div class="box_name">
                        <div>
                            <p>Your Inquiry</p>
                        </div>
                        <div>
                            <b>-</b>
                        </div>
                    </div>
                    <div class="application box_content">
                        <div class="line_inputs">
                            <div>
                                <input type="text" class="right_in" placeholder="Name">
                            </div>
                            <div>
                                <input type="text" class="right_in" placeholder="Email">
                            </div>
                        </div>
                        <div class="line_inputs">
                            <div>
                                <input type="text" class="right_in" placeholder="Website">
                            </div>
                            <div>
                                <select name="" class="right_in" aria-invalid="false" id="">
                                    <option value="Department">Department</option>
                                    <option value="Cargo">Cargo</option>
                                    <option value="Logistics">Logistics</option>
                                </select>
                            </div>
                        </div>
                        <div class="main_message"><textarea name="" class="right_in" placeholder="Message" id=""
                                cols="30" rows="10"></textarea></div>
                        <div><button>SEND A MESSAGE</button></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="layouts_js/icon_hover.js"></script>
<script src="layouts_js/header_menu.js"></script>
<script src="local_js/scroll.js"></script>
<script src="local_js/box_block.js"></script>
<script src="./swiper-bundle.min.js"></script>
<script src="layouts_js/icon_hover.js"></script>
<script src="banner.js"></script>

</html>