<div class="content">


    <section class="section banner">
        <div class="banner-block__loading">
            <div class="banner-block__loading-inner"></div>
        </div>
        <div class="banner-slider swiper-container">
            <button class="banner-slider__prev">
                <img src="./img/arrow-left.svg" alt="">
            </button>
            <button class="banner-slider__next">
                <img src="./img/arrow-right.svg" alt="">
            </button>
            <div class="swiper-wrapper">
                <div class="swiper-slide banner__block banner-block">
                    <img src="./img/banner-img1.jpg" class="banner-block__bg" alt="">
                    <div class="banner-block__content">
                        <div class="banner-block__red">
                            <p class="banner-block__red__text">
                                FAST. <br>
                                FIRST. <br>
                                FLAWLESS! <br>
                            </p>
                        </div>
                        <div class="banner-block__white">
                            <img src="./img/banner-block-icon.jpg" alt="" class="banner-block__white__icon">
                            <p class="banner-block__white__text">
                                Transport quality and excellence <br>
                                to enhance your business
                            </p>
                            <div class="banner-block__white__bottom">
                                <p class="banner-block__white__bottom__text">
                                    READ MORE
                                </p>
                                <img src="./img/triangle.svg" class="banner-block__white__bottom__icon" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide banner__block banner-block">
                    <img src="./img/banner-img2.jpg" class="banner-block__bg" alt="">
                    <div class="banner-block__content banner-block__content_reverse">
                        <div class="banner-block__red_reverse">
                            <p class="banner-block__red__text">
                                FAST. <br>
                                FIRST. <br>
                                FLAWLESS! <br>
                            </p>
                        </div>
                        <div class="banner-block__white_reverse">
                            <img src="./img/banner-block-icon.jpg" alt="" class="banner-block__white__icon">
                            <p class="banner-block__white__text">
                                Transport quality and excellence <br>
                                to enhance your business
                            </p>
                            <div class="banner-block__white__bottom">
                                <p class="banner-block__white__bottom__text">
                                    READ MORE
                                </p>
                                <img src="./img/triangle.svg" class="banner-block__white__bottom__icon" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide banner__block banner-block">
                    <img src="./img/banner-img3.jpg" class="banner-block__bg" alt="">
                    <div class="banner-block__content">
                        <div class="banner-block__red">
                            <p class="banner-block__red__text">
                                FAST. <br>
                                FIRST. <br>
                                FLAWLESS! <br>
                            </p>
                        </div>
                        <div class="banner-block__white">
                            <img src="./img/banner-block-icon.jpg" alt="" class="banner-block__white__icon">
                            <p class="banner-block__white__text">
                                Transport quality and excellence <br>
                                to enhance your business
                            </p>
                            <div class="banner-block__white__bottom">
                                <p class="banner-block__white__bottom__text">
                                    READ MORE
                                </p>
                                <img src="./img/triangle.svg" class="banner-block__white__bottom__icon" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide banner__block banner-block">
                    <img src="./img/banner-img4.jpg" class="banner-block__bg" alt="">
                    <div class="banner-block__content banner-block__content_reverse">
                        <div class="banner-block__red_reverse">
                            <p class="banner-block__red__text">
                                FAST. <br>
                                FIRST. <br>
                                FLAWLESS! <br>
                            </p>
                        </div>
                        <div class="banner-block__white_reverse">
                            <img src="./img/banner-block-icon.jpg" alt="" class="banner-block__white__icon">
                            <p class="banner-block__white__text">
                                Transport quality and excellence <br>
                                to enhance your business
                            </p>
                            <div class="banner-block__white__bottom">
                                <p class="banner-block__white__bottom__text">
                                    READ MORE
                                </p>
                                <img src="./img/triangle.svg" class="banner-block__white__bottom__icon" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner-bottom">
                <button class="banner-bottom__play active">
                    >
                </button>
                <div class="banner-pagination"></div>
                <button class="banner-bottom__pause">
                    <img src="./img/pause.svg" class="banner-bottom__pause__icon" alt="">
                </button>
            </div>
        </div>
    </section>


</div>
</body>