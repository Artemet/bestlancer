function icon_hover(){
    let hover_temp = 0;
    const get_icons = document.querySelectorAll(".header_line .network_list svg");
    get_icons.forEach( (item) => {
        item.addEventListener("mouseover", function(){
            hover_temp++;
            if (hover_temp === 1){
                setTimeout( () => {
                    item.classList.add("active");
                }, 200);
            }
        });
        item.addEventListener("mouseleave", function (){
            hover_temp = 0;
            item.classList.remove("active");
            setTimeout( () => {
                item.classList.remove("active");
            }, 200);
        });
    });
}
icon_hover();