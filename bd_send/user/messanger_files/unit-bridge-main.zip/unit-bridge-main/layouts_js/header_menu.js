function header_menu(){
    let mouse_temp = 0;
    const get_options = document.querySelectorAll(".header_line .menu_wrapper .option");
    get_options.forEach( (item) => {
        const item_large_menu = item.querySelectorAll(".large_menu");
        if (item_large_menu.length === 0){
            item.classList.add("normal_option");
        }
        item.addEventListener("mouseover", function (){
            mouse_temp++;
            if (mouse_temp === 1){
                const get_menu = item.querySelectorAll(".menu");
                if (get_menu.length >= 1){
                    if (!get_menu[0].className.includes("large_menu")){
                        get_menu[0].style.display = "block";
                    } else{
                        get_menu[0].style.display = "grid";
                    }
                    setTimeout( () => {
                        get_menu[0].style.marginTop = 0;
                        get_menu[0].style.opacity = 1;
                    }, 100);
                }
            }
        });
        item.addEventListener("mouseleave", function (){
            const get_menu = item.querySelectorAll(".menu");
            if (get_menu.length >= 1){
                get_menu[0].removeAttribute("style");
                get_menu[0].style.display = "none";
            }
            mouse_temp = 0;
        });
    });
}
header_menu();