//box_logic
function box_logic(){
    const get_box_names = document.querySelectorAll(".box_name");
    get_box_names.forEach( (item) => {
        const box_content = item.parentNode.querySelector(".box_content");
        const active_height = box_content.offsetHeight - 1;
        box_content.style.height = active_height + "px";
        item.addEventListener("click", function (){
            const box_element = item.querySelector("b");
            const box_content = item.parentNode.querySelector(".box_content");

            item.classList.toggle("hided");
            if (!item.className.includes("hided")){
                box_content.classList.remove("box_content_hide");
                setTimeout( () => {
                    box_element.innerHTML = "-";
                    box_element.removeAttribute("style");
                }, 300);
            } else{
                box_content.classList.add("box_content_hide");
                setTimeout( () => {
                    box_element.innerHTML = "+";
                    box_element.style.fontSize = "23px";
                    box_element.style.paddingTop = "6px";
                }, 300);
            }
        });
        //form_script
        const get_inputs = item.parentNode.querySelectorAll(".right_in");
        if (get_inputs.length >= 1){
            let input_values = [];
            const get_button = item.parentNode.querySelector("button");
            get_button.addEventListener("click", function (){
                const get_inputs = this.closest(".application_box").querySelectorAll(".right_in");
                if (input_values.length >= 1){
                    input_values.splice(0, input_values.length);
                }
                get_inputs.forEach( (item) => {
                    if (item.value.length !== 0){
                        input_values.push(item.value);
                    }
                });
                if (input_values.length !== get_inputs.length){
                    alert("Finish your quick quote!");
                } else{
                    $.ajax({
                        method: "POST",
                        url: "mail/application.php",
                        data: { name: "Artem" },
                    })
                        .done(function (respone){
                            alert("Done!");
                        });
                }
            });
        }
    });
}
box_logic();