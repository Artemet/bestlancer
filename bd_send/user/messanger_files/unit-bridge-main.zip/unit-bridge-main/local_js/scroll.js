//scroll_functions
function header_line_scroll(){
    const get_contact_wrapper = document.querySelector(".header_line .contact_wrapper");
    const get_main_wrapper = document.querySelector(".header_line .main_wrapper");
    function scroll_check(){
        if (pageYOffset >= 80){
            get_contact_wrapper.classList.add("contact_wrapper_hide");
            get_main_wrapper.classList.add("main_wrapper_scroll");
        } else{
            get_contact_wrapper.classList.remove("contact_wrapper_hide");
            get_main_wrapper.classList.remove("main_wrapper_scroll");
        }
    }
    if (pageYOffset >= 1){
        scroll_check();
    }
    window.addEventListener("scroll", function (){
        scroll_check();
    });
}
header_line_scroll();
function home_scroll(){
    //rate_scroll
    let rate_work = false;
    function rate_scroll(){
        let percent_temp_one = 0;
        let percent_temp_two = 0;
        let percent_temp_three = 0;
        const level_arr = [76, 80, 92];

        const get_years = document.querySelectorAll(".history_request_container .information p");
        const get_percents = document.querySelectorAll(".history_request_container .percent");
        const get_lines = document.querySelectorAll(".history_request_container .main_line");

        setTimeout(() => {
            setTimeout(() => {
                get_years.forEach((item) => {
                    item.classList.add("active");
                });
            }, 300);

            get_percents.forEach((item) => {
                item.classList.add("percent_active");
            });
        }, 500);

        const maxDuration = Math.max(...level_arr) * 30;

        const interval_all = setInterval(() => {
            if (percent_temp_one <= level_arr[0]) {
                percent_temp_one++;
                get_percents[0].querySelector("span").innerHTML = percent_temp_one + "%";
                get_lines[0].style.width = percent_temp_one + "%";
            }

            if (percent_temp_two <= level_arr[1]) {
                percent_temp_two++;
                get_percents[1].querySelector("span").innerHTML = percent_temp_two + "%";
                get_lines[1].style.width = percent_temp_two + "%";
            }

            if (percent_temp_three <= level_arr[2]) {
                percent_temp_three++;
                get_percents[2].querySelector("span").innerHTML = percent_temp_three + "%";
                get_lines[2].style.width = percent_temp_three + "%";
            }

            if (percent_temp_one === level_arr[0] &&
                percent_temp_two === level_arr[1] &&
                percent_temp_three === level_arr[2]) {
                clearInterval(interval_all);
            }
            rate_work = true;
        }, 30);

        setTimeout(() => {
            clearInterval(interval_all);
        }, maxDuration);
    }

    window.addEventListener("scroll", function (){
        const display_height = window.innerHeight;
        
        const get_rate_line = document.querySelector(".history_request_container .rates");

        if (pageYOffset > get_rate_line.offsetTop - display_height) {
            if (rate_work === false){
                rate_scroll();
            }
        }
    });
}
home_scroll();
//top_scroll
function top_scroll(){
    //arrow_show
    window.addEventListener("scroll", function (){
        const get_arrow = document.querySelector(".list_arrow");
        if (pageYOffset >= 235){
            get_arrow.style.display = "block";
            setTimeout( () => {
                get_arrow.style.opacity = 1;
            }, 100);
        } else{
            if (get_arrow.hasAttribute("style")){
                get_arrow.style.opacity = 0;
                setTimeout( () => {
                    get_arrow.removeAttribute("style");
                }, 500);
            }
        }
    });
    //arrow_click
    const get_arrow = document.querySelector(".list_arrow");
    get_arrow.addEventListener("click", function (){
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
}
top_scroll();