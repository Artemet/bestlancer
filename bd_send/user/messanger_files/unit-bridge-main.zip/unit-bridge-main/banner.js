// Slider

let customAutoPlay = true;

const playButton = document.querySelector('.banner-bottom__play');
const pauseButton = document.querySelector('.banner-bottom__pause');

playButton.addEventListener('click', () => {
    customAutoPlay = true;
    playButton.classList.add('active');
    pauseButton.classList.remove('active');
    // // swiper.autoplay.start();
    startLoad();
})

pauseButton.addEventListener('click', () => {
    customAutoPlay = false;
    playButton.classList.remove('active');
    pauseButton.classList.add('active');
    // // swiper.autoplay.stop();
})

const swiper = new Swiper('.banner-slider', {
    items: 1,
    slidesPerGroup: 1,
    slidesPerView: 1,
    centeredSlides: true,
    speed: 1500,
    allowTouchMove: false,
    loop: true,
    // autoplay: {
    //     delay: 5000,
    //     pauseOnMouseEnter: true,
    //     disableOnInteraction: true
    // },
    navigation: {
        nextEl: '.banner-slider__next',
        prevEl: '.banner-slider__prev',
    },
    pagination: {
        el: '.banner-pagination',
        clickable: true,
        renderBullet: function (index, className) {
            return `<span class="${className}" data-index="${index}"></span>`;
        },
    },
});

const picturesForSlider = ['./img/banner-img1.jpg', './img/banner-img2.jpg', './img/banner-img3.jpg', './img/banner-img4.jpg']
const bullets = document.querySelectorAll('.banner-pagination .swiper-pagination-bullet');

bullets.forEach((bullet, index) => {
    bullet.addEventListener('mouseenter', () => {
        bullet.style.setProperty('--background-image', `url('${picturesForSlider[index]}')`);
    });
});


function startLoad() {
    const loadingCircle = document.querySelector('.banner-block__loading');
    const activeSlides = document.querySelectorAll('.banner-block');
    const slideNextBtn = document.querySelector('.banner-slider__next');
    const slidePrevBtn = document.querySelector('.banner-slider__prev');
    const slidePrevPagination = document.querySelector('.banner-bottom');
    let progressStartValue = 0;
    let speed = 45;
    let isPaused = false;
    let progressTimer = setInterval(() => {
        if (!isPaused) {
            progressStartValue++;
            if (progressStartValue === 100) {
                if(customAutoPlay) {
                    swiper.slideNext();
                    endLoad();
                }
                clearInterval(progressTimer);
            }
            loadingCircle.style.background = `
    conic-gradient(#b2b2b2 ${3.6 * progressStartValue}deg, transparent 0deg)`;
        }
    }, speed);
    let mouse_check = false;
    document.querySelectorAll(".banner-block__content").forEach( (item) => {
        item.addEventListener("mouseover", function (){
            isPaused = true;
            mouse_check = true;
        });
        item.addEventListener("mouseleave", function (){
            mouse_check = false;
        });
    });
    activeSlides.forEach(activeSlide => {
        activeSlide.addEventListener('mouseenter', () => {
            isPaused = true;
        })
        activeSlide.addEventListener('mouseout', () => {
            if (mouse_check === false){
                isPaused = false;
            }
        });
    });
    slideNextBtn.firstElementChild.addEventListener('mouseenter', () => {
        isPaused = true;
    })
    slideNextBtn.firstElementChild.addEventListener('mouseout', () => {
        isPaused = false;
    })
    slidePrevBtn.firstElementChild.addEventListener('mouseenter', () => {
        isPaused = true;
    })
    slidePrevBtn.firstElementChild.addEventListener('mouseout', () => {
        isPaused = false;
    })
    slidePrevPagination.addEventListener('mouseenter', () => {
        isPaused = true;
    })
    slidePrevPagination.addEventListener('mouseout', () => {
        isPaused = false;
    })
    bullets.forEach(bullet => {
        bullet.addEventListener('mouseenter', () => {
            isPaused = true;
        })
        bullet.addEventListener('mouseout', () => {
            isPaused = false;
        })
        bullet.addEventListener('click', () => {
            clearInterval(progressTimer);
            endLoad();
        })
    })

    slideNextBtn.addEventListener('click', () => {
        clearInterval(progressTimer);
        endLoad();
    })

    slidePrevBtn.addEventListener('click', () => {
        clearInterval(progressTimer);
        endLoad();
    })
}

function endLoad() {
    const loadingCircle = document.querySelector('.banner-block__loading');
    let progressStartValue = 100;
    let speed = 1;
    let progressTimer = setInterval(() => {
        progressStartValue--;
        if (progressStartValue === 0) {
            clearInterval(progressTimer);
        }
        loadingCircle.style.background = `
    conic-gradient(#b2b2b2 ${3.6 * progressStartValue}deg, transparent 0deg)`;
    }, speed);
}

swiper.on('slideChange', function () {
    startLoad();
});

startLoad();