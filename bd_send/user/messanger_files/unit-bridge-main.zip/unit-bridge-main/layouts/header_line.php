<div class="header_line_wrapper">
    <div class="header_line">
        <div class="contact_wrapper">
            <div class="link_list">
                <div>
                    <a href="">FAQ</a>
                </div>
                <div>
                    <a href="">Track Shipment</a>
                </div>
                <div>
                    <a href="">Help Desk</a>
                </div>
            </div>
            <div class="network_list">
                <div>
                    <a href="">
                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="14"
                            viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M100.3 448H7.4V148.9h92.9zM53.8 108.1C24.1 108.1 0 83.5 0 53.8a53.8 53.8 0 0 1 107.6 0c0 29.7-24.1 54.3-53.8 54.3zM447.9 448h-92.7V302.4c0-34.7-.7-79.2-48.3-79.2-48.3 0-55.7 37.7-55.7 76.7V448h-92.8V148.9h89.1v40.8h1.3c12.4-23.5 42.7-48.3 87.9-48.3 94 0 111.3 61.9 111.3 142.3V448z" />
                        </svg>
                    </a>
                </div>
                <div>
                    <a href="">
                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="10"
                            viewBox="0 0 320 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M80 299.3V512H196V299.3h86.5l18-97.8H196V166.9c0-51.7 20.3-71.5 72.7-71.5c16.3 0 29.4 .4 37 1.2V7.9C291.4 4 256.4 0 236.2 0C129.3 0 80 50.5 80 159.4v42.1H14v97.8H80z" />
                        </svg>
                    </a>
                </div>
                <div>
                    <a href="">
                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16"
                            viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M459.4 151.7c.3 4.5 .3 9.1 .3 13.6 0 138.7-105.6 298.6-298.6 298.6-59.5 0-114.7-17.2-161.1-47.1 8.4 1 16.6 1.3 25.3 1.3 49.1 0 94.2-16.6 130.3-44.8-46.1-1-84.8-31.2-98.1-72.8 6.5 1 13 1.6 19.8 1.6 9.4 0 18.8-1.3 27.6-3.6-48.1-9.7-84.1-52-84.1-103v-1.3c14 7.8 30.2 12.7 47.4 13.3-28.3-18.8-46.8-51-46.8-87.4 0-19.5 5.2-37.4 14.3-53 51.7 63.7 129.3 105.3 216.4 109.8-1.6-7.8-2.6-15.9-2.6-24 0-57.8 46.8-104.9 104.9-104.9 30.2 0 57.5 12.7 76.7 33.1 23.7-4.5 46.5-13.3 66.6-25.3-7.8 24.4-24.4 44.8-46.1 57.8 21.1-2.3 41.6-8.1 60.4-16.2-14.3 20.8-32.2 39.3-52.6 54.3z" />
                        </svg>
                    </a>
                </div>
                <div>
                    <a href="">
                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="14"
                            viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M424.7 299.8c2.9-14 4.7-28.9 4.7-43.8 0-113.5-91.9-205.3-205.3-205.3-14.9 0-29.7 1.7-43.8 4.7C161.3 40.7 137.7 32 112 32 50.2 32 0 82.2 0 144c0 25.7 8.7 49.3 23.3 68.2-2.9 14-4.7 28.9-4.7 43.8 0 113.5 91.9 205.3 205.3 205.3 14.9 0 29.7-1.7 43.8-4.7 19 14.6 42.6 23.3 68.2 23.3 61.8 0 112-50.2 112-112 .1-25.6-8.6-49.2-23.2-68.1zm-194.6 91.5c-65.6 0-120.5-29.2-120.5-65 0-16 9-30.6 29.5-30.6 31.2 0 34.1 44.9 88.1 44.9 25.7 0 42.3-11.4 42.3-26.3 0-18.7-16-21.6-42-28-62.5-15.4-117.8-22-117.8-87.2 0-59.2 58.6-81.1 109.1-81.1 55.1 0 110.8 21.9 110.8 55.4 0 16.9-11.4 31.8-30.3 31.8-28.3 0-29.2-33.5-75-33.5-25.7 0-42 7-42 22.5 0 19.8 20.8 21.8 69.1 33 41.4 9.3 90.7 26.8 90.7 77.6 0 59.1-57.1 86.5-112 86.5z" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
        <div class="main_wrapper">
            <div>
                <img src="res/Unit-Bridge-Logo.png" alt="">
            </div>
            <div class="infromation">
                <div class="part">
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16"
                            viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M464 256A208 208 0 1 1 48 256a208 208 0 1 1 416 0zM0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM232 120V256c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2V120c0-13.3-10.7-24-24-24s-24 10.7-24 24z" />
                        </svg>
                    </div>
                    <div>
                        <div>
                            <p class="work_time">Sunday CLOSED</p>
                        </div>
                        <div>
                            <p class="main_information">MON - SAT 8.00 - 18.00</p>
                        </div>
                    </div>
                </div>
                <div class="part">
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="12"
                            viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M16 64C16 28.7 44.7 0 80 0H304c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H80c-35.3 0-64-28.7-64-64V64zM224 448a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM304 64H80V384H304V64z" />
                        </svg>
                    </div>
                    <div>
                        <div>
                            <p class="work_time">Call Us Anytime</p>
                        </div>
                        <div>
                            <p class="main_information">+90 532 064 31 64</p>
                        </div>
                    </div>
                </div>
                <div class="part last_part">
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="12"
                            viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z" />
                        </svg>
                    </div>
                    <div>
                        <div>
                            <p class="work_time">Columbia, SC 29201</p>
                        </div>
                        <div>
                            <p class="main_information">227 MARION STREET</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="menu_wrapper">
            <div class="options_wrapper">
                <div class="option">
                    <div class="line active_line"></div>
                    <div class="wrapper">
                        <a href="">
                            <div>
                                <p class="name active_name">HOME</p>
                            </div>
                            <div>
                                <p class="about_page">Main page</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="option">
                    <div class="line"></div>
                    <div class="wrapper">
                        <div>
                            <p class="name">SERVICES</p>
                        </div>
                        <div>
                            <p class="about_page">Our services</p>
                        </div>
                    </div>
                    <div class="menu">
                        <div>
                            <p>Air Freight</p>
                        </div>
                        <div>
                            <p>Overland Transportation</p>
                        </div>
                        <div>
                            <p>Ground Cargo</p>
                        </div>
                        <div>
                            <p>Sea Freight</p>
                        </div>
                        <div>
                            <p>Project Logistics</p>
                        </div>
                        <div>
                            <p>Trucking Service</p>
                        </div>
                        <div>
                            <p>Supply Chain Management</p>
                        </div>
                        <div>
                            <p>Warehousing</p>
                        </div>
                        <div>
                            <p>Packaging Options</p>
                        </div>
                    </div>
                </div>
                <div class="option">
                    <div class="line"></div>
                    <div class="wrapper">
                        <div>
                            <p class="name">FEATURES</p>
                        </div>
                        <div>
                            <p class="about_page">Cool layouts</p>
                        </div>
                    </div>
                    <div class="menu">
                        <div>
                            <p>About Us</p>
                        </div>
                        <div>
                            <p>Pricing</p>
                        </div>
                        <div>
                            <p>Calculated Form</p>
                        </div>
                        <div>
                            <p>Testimonials</p>
                        </div>
                        <div>
                            <p>FAQ</p>
                        </div>
                        <div>
                            <p>Gallery</p>
                        </div>
                    </div>
                </div>
                <div class="option">
                    <div class="line"></div>
                    <div class="wrapper">
                        <div>
                            <p class="name">SHORTCODES</p>
                        </div>
                        <div>
                            <p class="about_page">Site elements</p>
                        </div>
                    </div>
                    <div class="menu large_menu">
                        <div class="large_part">
                            <h4>1</h4>
                            <div>
                                <div>
                                    <p>Buttons Shortcode</p>
                                </div>
                                <div>
                                    <p>Custom HTML, CSS, JS</p>
                                </div>
                                <div>
                                    <p>Dividers</p>
                                </div>
                                <div>
                                    <p>Icon Lists</p>
                                </div>
                                <div>
                                    <p>Portfolio Shortcode</p>
                                </div>
                                <div>
                                    <p>Quotes</p>
                                </div>
                            </div>
                        </div>
                        <div class="large_part">
                            <h4>2</h4>
                            <div>
                                <div>
                                    <p>Image</p>
                                </div>
                                <div>
                                    <p>Google Maps</p>
                                </div>
                                <div>
                                    <p>Gallery</p>
                                </div>
                                <div>
                                    <p>Embedded</p>
                                </div>
                                <div>
                                    <p>Featured Blocks</p>
                                </div>
                                <div>
                                    <p>Posts or Projects Slider</p>
                                </div>
                                <div>
                                    <p>Profiles</p>
                                </div>
                            </div>
                        </div>
                        <div class="large_part">
                            <h4>3</h4>
                            <div>
                                <div>
                                    <p>Tables</p>
                                </div>
                                <div>
                                    <p>Social Sharing</p>
                                </div>
                                <div>
                                    <p>Counters & Progress Bars</p>
                                </div>
                                <div>
                                    <p>Icon Boxes</p>
                                </div>
                                <div>
                                    <p>Notice Boxes</p>
                                </div>
                                <div>
                                    <p>Pricing Tables</p>
                                </div>
                                <div>
                                    <p>Profiles</p>
                                </div>
                            </div>
                        </div>
                        <div class="large_part">
                            <h4>4</h4>
                            <div>
                                <div>
                                    <p>Sidebar</p>
                                </div>
                                <div>
                                    <p>Sliders</p>
                                </div>
                                <div>
                                    <p>Toggles & Accordions</p>
                                </div>
                                <div>
                                    <p>Tabs & Tours</p>
                                </div>
                                <div>
                                    <p>Blog Shortcode</p>
                                </div>
                                <div>
                                    <p>Clients</p>
                                </div>
                                <div>
                                    <p>Tweets</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="option">
                    <div class="line"></div>
                    <div class="wrapper">
                        <div>
                            <p class="name">POST TYPES</p>
                        </div>
                        <div>
                            <p class="about_page">Great features</p>
                        </div>
                    </div>
                    <div class="menu large_menu">
                        <div class="large_part">
                            <h4>BLOG</h4>
                            <div>
                                <div>
                                    <p>BLOG Standard Blog</p>
                                </div>
                                <div>
                                    <p>Masonry Blog</p>
                                </div>
                                <div>
                                    <p>Timeline Blog</p>
                                </div>
                            </div>
                        </div>
                        <div class="large_part">
                            <h4>PROJECTS GRID</h4>
                            <div>
                                <div>
                                    <p>Large Gap</p>
                                </div>
                                <div>
                                    <p>No Gap</p>
                                </div>
                                <div>
                                    <p>1 Pixel Gap</p>
                                </div>
                            </div>
                        </div>
                        <div class="large_part">
                            <h4>MASONRY PUZZLE</h4>
                            <div>
                                <div>
                                    <p>Large Gap</p>
                                </div>
                                <div>
                                    <p>No Gap</p>
                                </div>
                                <div>
                                    <p>1 Pixel Gap</p>
                                </div>
                            </div>
                        </div>
                        <div class="large_part">
                            <h4>PROFILES</h4>
                            <div>
                                <div>
                                    <p>Horizontal</p>
                                </div>
                                <div>
                                    <p>Vertical</p>
                                </div>
                                <div>
                                    <p>Open Profile</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="option">
                    <div class="line"></div>
                    <div class="wrapper last_option">
                        <a href="">
                            <div>
                                <p class="name">CONTACTS</p>
                            </div>
                            <div>
                                <p class="about_page">Contact info</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>